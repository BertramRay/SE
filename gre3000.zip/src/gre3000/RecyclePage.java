package gre3000;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;

public class RecyclePage extends Page
{
	ArrayList<String> list = new ArrayList<String>();
	private int size = 3000;
	String a[] = new String[size];
	String b[] = new String[size];
	JList JL_w,JL_p ;
	int pos = 0;
	int page = 1;
	public RecyclePage(JFrame jf) {
		super(jf);
		// TODO Auto-generated constructor stub
	}

	public void setPageNum(int n)
	{
		page = n;
	}
	
	public ArrayList<String> readFromTextFile(String pathname) throws IOException
	{
	    ArrayList<String> strArray = new ArrayList<String>();
	    File filename = new File(pathname);
	    InputStreamReader reader = new InputStreamReader(new FileInputStream(filename));
	    BufferedReader br = new BufferedReader(reader);
	    String line = "";
	    line = br.readLine();
	    while(line != null) 
	    {
	        strArray.add(line);
	        line = br.readLine();
	    }
	    return strArray;
	}
	
	public void input() throws IOException
	{
		DefaultListModel<String> model_a = new DefaultListModel<>();
		DefaultListModel<String> model_b = new DefaultListModel<>();
    	String init[] = {"cmd","/k","main.exe"};
    	String cmd[] = {"show recycle",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter"
    	};
    	
		try
    	{
			Process process1 = Runtime.getRuntime().exec(init);
			PrintWriter out = new PrintWriter(process1.getOutputStream());
			java.io.InputStream is = process1.getInputStream();
			DataInputStream  dis = new DataInputStream(is);
			InputStreamReader isr = new InputStreamReader (dis);
			BufferedReader br = new BufferedReader(isr);
			for(int i=0;i<page;i++)
			{
				pos = 0;
				out.println(cmd[i]);
				out.flush(); 
				System.out.println(cmd[i]);
				while(true)
				{
					String s = br.readLine();
					System.out.println(s);
					if(s.length()==0)
						break;
					if(s.charAt(0)=='$')
						break;
					
					for(int j=0;j<s.length();j++)
					{
						//System.out.println((int)s.charAt(j));
						if((int)s.charAt(j)==9)
						{
							a[pos] = s.substring(0, j);
							b[pos] = s.substring(j+1);
							
							//System.out.println(a[pos]);
							//System.out.println(b[pos]);
							pos++;
							break;
						}
					}
				}
			}
			out.println("quit");
			out.flush(); //д������̨ 
    	}
		catch (IOException e1) 
		{
		// TODO Auto-generated catch block
		e1.printStackTrace();
		}
		for(int i=0;i<pos;i++)
		{
			model_a.addElement("<html><body><div style='color:#36648B;font-size:22px;font-family:����;'>"+a[i]+"</div></body></html>");
			model_b.addElement("<html><body><div style='color:#36648B;font-size:22px;font-family:����;'>"+b[i]+"</div></body></html>");
		}
		JL_w = new JList<>(model_a);
		JL_p = new JList<>(model_b);
	}
	
	public void setPage()
	{
		jp.setLayout(null);
		
		buttonWidth = 100;
		buttonHeight = 40;

		width = jf.getWidth();
		height = jf.getHeight();
		
		int delta = width/100;
		
		//����������
		ImageIcon img1 = new ImageIcon("image/background.jpg");
		JLabel bg=new JLabel(img1);
		bg.setBounds(0, 0,img1.getIconWidth(), img1.getIconHeight());
		jf.getLayeredPane().add(bg, new Integer(Integer.MIN_VALUE));
		jp.setOpaque(false);
		
		ImageIcon img2 = new ImageIcon("image/title.png");
		JLabel ti = new JLabel(img2);
		ti.setBounds(0, 0,img2.getIconWidth(), img2.getIconHeight());
		
		try {
			input();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JL_w.setBackground(null);
		JL_w.setBounds(width/2-25*delta,height/2-12*delta,20*delta,30*delta);
		JL_w.setBackground(new Color(255,255,255,0));
		JL_w.setOpaque(false);

		JL_w.addMouseListener(new MouseAdapter() 
		{
			public void mousePressed(MouseEvent e) 
			{
				int i = JL_w.getSelectedIndex();
				WordPage WP = new WordPage(jf);
				WP.setName(a[i]);
				WP.setparaphrase(b[i]);
				WP.setPageNum(page);
				WP.setCategory(RECYCLE);
				jf.remove(jp);
				jp = WP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});
		
		JL_p.setBackground(null);
		JL_p.setBounds(width/2-5*delta,height/2-12*delta,30*delta,30*delta);
		JL_p.setBackground(new Color(255,255,255,0));
		JL_p.setOpaque(false);

		JL_p.addMouseListener(new MouseAdapter() 
		{
			public void mousePressed(MouseEvent e) 
			{
				int i = JL_p.getSelectedIndex();
				WordPage WP = new WordPage(jf);
				WP.setName(a[i]);
				WP.setparaphrase(b[i]);
				WP.setPageNum(page);
				WP.setCategory(RECYCLE);
				jf.remove(jp);
				jp = WP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});
		
		JButton ReturnButton;
		ImageIcon img_rt = new ImageIcon("image/return_icon.png");
		ReturnButton = new JButton(img_rt);
		ReturnButton.setBounds(width/9*8-returnWidth/2,height/7*6-returnHeight/2,returnWidth,returnHeight);
		ReturnButton.setContentAreaFilled(false); 
		ReturnButton.setBorder(emptyBorder);
		ReturnButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				VocabularyPage FP = new VocabularyPage(jf);
				jf.remove(jp);
				jp = FP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});

		ImageIcon img_last = new ImageIcon("image/last.png");
		JButton LastButton =  new JButton(img_last);
		LastButton.setBounds(width/2-40*delta,height/2-5*delta,80,80);
		LastButton.setContentAreaFilled(false); 
		LastButton.setBorder(emptyBorder);
		LastButton.addMouseListener(new MouseAdapter() 
		{
			public void mousePressed(MouseEvent e) 
			{
				RecyclePage RP = new RecyclePage(jf);
				jf.remove(jp);
				if(page>1)
					page--;
				RP.setPageNum(page);
				jp = RP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});

		ImageIcon img_next = new ImageIcon("image/next.png");
		JButton NextButton =  new JButton(img_next);
		NextButton.setBounds(width/2+30*delta,height/2-5*delta,80,80);
		NextButton.setContentAreaFilled(false); 
		NextButton.setBorder(emptyBorder);
		NextButton.addMouseListener(new MouseAdapter() 
		{
			public void mousePressed(MouseEvent e) 
			{
				RecyclePage RP = new RecyclePage(jf);
				jf.remove(jp);
				page++;
				RP.setPageNum(page);
				jp = RP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});

		jp.add(ReturnButton);
		jp.add(LastButton);
		jp.add(NextButton);
		jp.add(JL_w);
		jp.add(JL_p);
		jp.add(ti);
		jp.add(bg);
		
		jp.setBounds(0, 0, width, height);
	}
}
