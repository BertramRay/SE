package gre3000;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class WordPage extends Page
{
	String name;
	String paraphrase;
	String k = new String();
	int category;
	int page;
	public WordPage(JFrame jf)
	{
		super(jf);
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public void setparaphrase(String paraphrase)
	{
		this.paraphrase = paraphrase;
	}
	public void setCategory(int category)
	{
		this.category = category;
	}
	
	public void setK(String k)
	{
		this.k = k;
	}

	public void setPageNum(int page)
	{
		this.page = page;
	}
	
	public void setPage()
	{
		jp.setLayout(null);

		buttonWidth = 100;
		buttonHeight = 40;
		
		width = jf.getWidth();
		height = jf.getHeight();

		//����������
		ImageIcon img1 = new ImageIcon("image/background.jpg");
		JLabel bg=new JLabel(img1);
		bg.setBounds(0, 0,img1.getIconWidth(), img1.getIconHeight());
		jf.getLayeredPane().add(bg, new Integer(Integer.MIN_VALUE));
		jp.setOpaque(false);
						
		ImageIcon img2 = new ImageIcon("image/title.png");
		JLabel ti = new JLabel(img2);
		ti.setBounds(0, 0,img2.getIconWidth(), img2.getIconHeight());
		
		lableWidth = width/10*7;
		lableHeight = 50;

		//k = getK(name);
		System.out.println(k);
		
		JLabel nameLable = new JLabel("<html><body><div style='color:#36648B;font-size:22px;font-family:����;'>"+name+"</div></body></html>");
		nameLable.setBounds(width/5, height/4, lableWidth, lableHeight);
		JLabel Lable_1 = new JLabel("<html><body><div style='color:#36648B;font-size:22px;font-family:����;'>"+"���壺"+"</div></body></html>");
		Lable_1.setBounds(width/5, height/2-80, lableWidth, lableHeight);
		JLabel peraphaseLable = new JLabel("<html><body><div style='color:#36648B;font-size:22px;font-family:����;'>"+paraphrase+"</div></body></html>");
		peraphaseLable.setBounds(width/5, height/2-30, lableWidth, lableHeight);	
		
		ImageIcon img_col = new ImageIcon("image/collect.png");
		JButton CollectButton = new JButton(img_col);
		CollectButton.setBounds(width/9*8-returnWidth/2,height/7*2-returnHeight/2,85,85);
		CollectButton.setContentAreaFilled(false); 
		CollectButton.setBorder(emptyBorder);
		CollectButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{

		    	String init[] = {"cmd","/k","main.exe"};
		    	String cmd[] = {"add "+name+" collection" ,
		    			"del "+name+" recycle",
		    			"k "+name
		    	};
		    	
				try
		    	{
					Process process1 = Runtime.getRuntime().exec(init);
					PrintWriter out = new PrintWriter(process1.getOutputStream());
					
					for(int i=0;i<3;i++)
					{
						out.println(cmd[i]);
						out.flush(); 
					}
					out.println("quit");
					out.flush(); //д������̨ 
		    	}
				catch (IOException e1) 
				{
				// TODO Auto-generated catch block
				e1.printStackTrace();
				}

				jf.remove(jp);
				WordPage WP = new WordPage(jf);
				WP.setName(name);
				WP.setparaphrase(paraphrase);
				WP.setCategory(category);
				WP.setK(K);
				jp = WP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});

		ImageIcon img_del = new ImageIcon("image/delete.png");
		JButton DeleteButton = new JButton(img_del);
		DeleteButton.setBounds(width/9*8-returnWidth/2,height/7*2-returnHeight/2,85,85);
		DeleteButton.setContentAreaFilled(false); 
		DeleteButton.setBorder(emptyBorder);
		DeleteButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{

		    	String init[] = {"cmd","/k","main.exe"};
		    	String cmd[] = {"add "+name+" recycle" ,
		    			"del "+name+" collection",
		    			"unk "+name
		    	};
		    	
				try
		    	{
					Process process1 = Runtime.getRuntime().exec(init);
					PrintWriter out = new PrintWriter(process1.getOutputStream());
					for(int i=0;i<3;i++)
					{
						out.println(cmd[i]);
						out.flush(); 
						//System.out.println(cmd[i]);
					}
					out.println("quit");
					out.flush(); //д������̨ 
		    	}
				catch (IOException e1) 
				{
				// TODO Auto-generated catch block
				e1.printStackTrace();
				}

				jf.remove(jp);
				WordPage WP = new WordPage(jf);
				WP.setName(name);
				WP.setparaphrase(paraphrase);
				WP.setK(UNK);
				WP.setCategory(category);
				jp = WP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});
		
		JButton ReturnButton;
		ImageIcon img_rt = new ImageIcon("image/return_icon.png");
		ReturnButton = new JButton(img_rt);
		ReturnButton.setBounds(width/9*8-returnWidth/2,height/7*6-returnHeight/2,returnWidth,returnHeight);
		ReturnButton.setContentAreaFilled(false); 
		ReturnButton.setBorder(emptyBorder);
		ReturnButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				String cmd = k;
				String command[] = {exe2,cmd,name};
				try {
					Process process = Runtime.getRuntime().exec(command);
					
					try {
						process.waitFor();
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				jf.remove(jp);
				switch(category)
				{
					//define VIEW 1
					case 1:
					{
						ViewPage VP = new ViewPage(jf);
						VP.page = page;
						jp = VP.createPage();
						break;
					}
					//define COLLECTION 2
					case 2:
					{
						CollectionPage CP = new CollectionPage(jf);
						CP.page = page;
						jp = CP.createPage();
						break;
					}
					//define RECYCLE 3
					case 3:
					{
						RecyclePage RP = new RecyclePage(jf);
						RP.page = page;
						jp = RP.createPage();
						break;
					}
					default:
						;
				}
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});
		jp.add(ReturnButton);
		System.out.println(k);
		if(k.charAt(0)=='k')
		{
			System.out.println("collected");
			jp.add(DeleteButton);
		}
		else
		{
			System.out.println("not collected");
			jp.add(CollectButton);
		}
		jp.add(nameLable);
		jp.add(Lable_1);
		jp.add(peraphaseLable);
		jp.add(ti);
		jp.add(bg);
		
		jp.setBounds(0, 0, width, height);
	}
}
