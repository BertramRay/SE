package gre3000;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.lang.Character.UnicodeBlock;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JTextField;

import java.io.InputStream;

public class ViewPage extends Page
{
	ArrayList<String> list = new ArrayList<String>();
	private int size = 3000;
	String a[] = new String[size];
	String b[] = new String[size];
	String word0 = new String();
	String paraphrase0 = new String();
	int pos = 0;
	int page = 1;
	JList JL_w,JL_p ;
	
	public ViewPage(JFrame jf) {
		super(jf);
		// TODO Auto-generated constructor stub
	}

	public void setPageNum(int n)
	{
		page = n;
	}
	
	public ArrayList<String> readFromTextFile(String pathname) throws IOException
	{
	    ArrayList<String> strArray = new ArrayList<String>();
	    File filename = new File(pathname);
	    InputStreamReader reader = new InputStreamReader(new FileInputStream(filename));
	    BufferedReader br = new BufferedReader(reader);
	    String line = "";
	    line = br.readLine();
	    while(line != null) 
	    {
	        strArray.add(line);
	        line = br.readLine();
	    }
	    return strArray;
	}
	

	public String getK(String name)
	{
		String cmd = "remember";
		String command[] = {exe2,cmd,name};
		String buffer = new String();
		try {
			Process process = Runtime.getRuntime().exec(command);
			java.io.InputStream is = process.getInputStream();
			DataInputStream  dis = new DataInputStream(is);
			InputStreamReader isr = new InputStreamReader (dis);
			BufferedReader br = new BufferedReader(isr);
			buffer = br.readLine();
			
			try {
				process.waitFor();
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return buffer;
	}
	
	
	
	//����
	public void input() throws IOException
	{
		DefaultListModel<String> model_a = new DefaultListModel<>();
		DefaultListModel<String> model_b = new DefaultListModel<>();
    	String init[] = {"cmd","/k","main.exe"};
    	String cmd[] = {"show dictlist",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter"
    	};
    	
		try
    	{
			Process process1 = Runtime.getRuntime().exec(init);
			PrintWriter out = new PrintWriter(process1.getOutputStream());
			java.io.InputStream is = process1.getInputStream();
			DataInputStream  dis = new DataInputStream(is);
			InputStreamReader isr = new InputStreamReader (dis);
			BufferedReader br = new BufferedReader(isr);
			for(int i=0;i<page;i++)
			{
				pos = 0;
				out.println(cmd[i]);
				out.flush(); 
				//System.out.println(cmd[i]);
				while(true)
				{
					String s = br.readLine();
					if(s.length()==0)
						break;
					if(s.charAt(0)=='$')
						break;
					//System.out.println(s.length());
					
					for(int j=0;j<s.length();j++)
					{
						//System.out.println((int)s.charAt(j));
						if((int)s.charAt(j)==9)
						{
							a[pos] = s.substring(0, j);
							b[pos] = s.substring(j+1);
							
							//System.out.println(a[pos]);
							//System.out.println(b[pos]);
							pos++;
							break;
						}
					}
				}
				/*
				try
				{
					process1.waitFor();
				} catch (InterruptedException e1)
				{
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}*/
			}

			//System.out.println("miao");
			out.println("quit");
			out.flush(); //д������̨ 
    	}
		catch (IOException e1) 
		{
		// TODO Auto-generated catch block
		e1.printStackTrace();
		}
		for(int i=0;i<pos;i++)
		{
			model_a.addElement("<html><body><div style='color:#36648B;font-size:22px;font-family:����;'>"+a[i]+"</div></body></html>");
			model_b.addElement("<html><body><div style='color:#36648B;font-size:22px;font-family:����;'>"+b[i]+"</div></body></html>");
		}
		JL_w = new JList<>(model_a);
		JL_p = new JList<>(model_b);
	}

	public void setPage()
	{
		jp.setLayout(null);
		
		buttonWidth = 100;
		buttonHeight = 40;

		width = jf.getWidth();
		height = jf.getHeight();
		
		int delta = width/100;
		
		//����������
		ImageIcon img1 = new ImageIcon("image/background.jpg");
		JLabel bg=new JLabel(img1);
		bg.setBounds(0, 0,img1.getIconWidth(), img1.getIconHeight());
		jf.getLayeredPane().add(bg, new Integer(Integer.MIN_VALUE));
		jp.setOpaque(false);
		
		ImageIcon img2 = new ImageIcon("image/title.png");
		JLabel ti = new JLabel(img2);
		ti.setBounds(0, 0,img2.getIconWidth(), img2.getIconHeight());
		
		try {
			input();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JTextField jt = new JTextField();
		jt.setBounds(width/2-25*delta,height/2-20*delta,50*delta,5*delta);

		JLabel wordLabel = new JLabel();
		wordLabel = new JLabel("<html><body><div style='color:#36648B;font-size:22px;font-family:����;'>"+word0+"</div></body></html>");
		wordLabel.setBounds(width/2-25*delta,height/2-15*delta,20*delta,10*delta);
		
		wordLabel.addMouseListener(new MouseAdapter() 
		{
			public void mousePressed(MouseEvent e) 
			{
				;
				WordPage WP = new WordPage(jf);
				WP.setName(word0);
				WP.setparaphrase(paraphrase0);

				WP.setK(getK(word0));
				WP.setPageNum(page);
				WP.setCategory(VIEW);
				jf.remove(jp);
				jp = WP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});
		
		JLabel paraphraseLabel = new JLabel();
		paraphraseLabel = new JLabel("<html><body><div style='color:#36648B;font-size:22px;font-family:����;'>"+paraphrase0+"</div></body></html>");
		paraphraseLabel.setBounds(width/2-5*delta,height/2-15*delta,30*delta,10*delta);
		paraphraseLabel.addMouseListener(new MouseAdapter() 
		{
			public void mousePressed(MouseEvent e) 
			{
				WordPage WP = new WordPage(jf);
				WP.setName(word0);
				WP.setparaphrase(paraphrase0);
				WP.setK(getK(word0));
				WP.setPageNum(page);
				WP.setCategory(VIEW);
				jf.remove(jp);
				jp = WP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});

		JButton SearchButton;
		ImageIcon img_s = new ImageIcon("image/search.png");
		SearchButton = new JButton(img_s);
		SearchButton.setContentAreaFilled(false); 
		SearchButton.setBorder(emptyBorder);
		SearchButton.setBounds(width/2+29*delta,height/2-20*delta-2*delta,90,90);
		SearchButton.addMouseListener(new MouseAdapter() 
		{
			public void mousePressed(MouseEvent e) 
			{
				String s = jt.getText();
				if(s.length()!=0)
				{
					String cmd = "search";
					String argv1 = s;
					word0 = s;
					String command[] = {exe2,cmd,argv1};
					try {
						Process process = Runtime.getRuntime().exec(command);
						java.io.InputStream is = process.getInputStream();
						DataInputStream  dis = new DataInputStream(is);
						InputStreamReader isr = new InputStreamReader (dis);
						BufferedReader br = new BufferedReader(isr);
						paraphrase0 = br.readLine();
						
						try {
							process.waitFor();
						} catch (InterruptedException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
			
					ViewPage VP = new ViewPage(jf);
					jf.remove(jp);
					VP.word0 = word0;
					VP.paraphrase0 = paraphrase0;
					jp = VP.createPage();
					jf.add(jp);
					jp.revalidate();
					jp.repaint();
				}
			}
		});
		
		ImageIcon img_last = new ImageIcon("image/last.png");
		JButton LastButton =  new JButton(img_last);
		LastButton.setBounds(width/2-40*delta,height/2,80,80);
		LastButton.setContentAreaFilled(false); 
		LastButton.setBorder(emptyBorder);
		LastButton.addMouseListener(new MouseAdapter() 
		{
			public void mousePressed(MouseEvent e) 
			{
				ViewPage VP = new ViewPage(jf);
				jf.remove(jp);
				VP.word0 = word0;
				VP.paraphrase0 = paraphrase0;
				if(page>1)
					page--;
				VP.setPageNum(page);
				jp = VP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});
		
		ImageIcon img_next = new ImageIcon("image/next.png");
		JButton NextButton =  new JButton(img_next);
		NextButton.setBounds(width/2+30*delta,height/2,80,80);
		NextButton.setContentAreaFilled(false); 
		NextButton.setBorder(emptyBorder);
		NextButton.addMouseListener(new MouseAdapter() 
		{
			public void mousePressed(MouseEvent e) 
			{
				ViewPage VP = new ViewPage(jf);
				jf.remove(jp);
				VP.word0 = word0;
				VP.paraphrase0 = paraphrase0;
				page++;
				VP.setPageNum(page);
				jp = VP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});
		
		
		
		
		
		JL_w.setBackground(null);
		JL_w.setBounds(width/2-25*delta,height/2-5*delta,20*delta,30*delta);
		JL_w.setBackground(new Color(255,255,255,0));
		JL_w.setOpaque(false);

		JL_w.addMouseListener(new MouseAdapter() 
		{
			public void mousePressed(MouseEvent e) 
			{
				int i = JL_w.getSelectedIndex();
				//System.out.println(i);
				WordPage WP = new WordPage(jf);
				WP.setName(a[i]);
				WP.setparaphrase(b[i]);
				WP.setK(getK(a[i]));
				WP.setPageNum(page);
				WP.setCategory(VIEW);
				jf.remove(jp);
				jp = WP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});

		JL_p.setBackground(null);
		JL_p.setBounds(width/2-5*delta,height/2-5*delta,30*delta,30*delta);
		JL_p.setBackground(new Color(255,255,255,0));
		JL_p.setOpaque(false);

		JL_p.addMouseListener(new MouseAdapter() 
		{
			public void mousePressed(MouseEvent e) 
			{
				int i = JL_p.getSelectedIndex();
				//System.out.println(i);
				WordPage WP = new WordPage(jf);
				WP.setName(a[i]);
				WP.setparaphrase(b[i]);
				WP.setK(getK(a[i]));
				WP.setPageNum(page);
				WP.setCategory(VIEW);
				jf.remove(jp);
				jp = WP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});
		
		JButton ReturnButton;
		ImageIcon img_rt = new ImageIcon("image/return_icon.png");
		ReturnButton = new JButton(img_rt);
		ReturnButton.setBounds(width/9*8-returnWidth/2,height/7*6-returnHeight/2,returnWidth,returnHeight);
		ReturnButton.setContentAreaFilled(false); 
		ReturnButton.setBorder(emptyBorder);
		ReturnButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				VocabularyPage FP = new VocabularyPage(jf);
				jf.remove(jp);
				jp = FP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});
		
		jp.add(ReturnButton);
		jp.add(SearchButton);
		jp.add(LastButton);
		jp.add(NextButton);
		jp.add(jt);
		jp.add(wordLabel);
		jp.add(paraphraseLabel);
		jp.add(JL_w);
		jp.add(JL_p);
		jp.add(ti);
		jp.add(bg);
		jp.setBounds(0, 0, width, height);
	}
}
