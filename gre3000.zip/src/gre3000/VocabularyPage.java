package gre3000;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VocabularyPage extends Page
{
	public VocabularyPage(JFrame jf) {
		super(jf);
		// TODO Auto-generated constructor stub
	}

	public void setPage()
	{
		jp.setLayout(null);
		
		buttonWidth = 180;
		buttonHeight = 180;
		lableWidth = 65;
		lableHeight = 40;
		
		width = jf.getWidth();
		height = jf.getHeight();

		int delta = width/200;
		
		//����������
		ImageIcon img1 = new ImageIcon("image/background.jpg");
		JLabel bg=new JLabel(img1);
		bg.setBounds(0, 0,img1.getIconWidth(), img1.getIconHeight());
		jf.getLayeredPane().add(bg, new Integer(Integer.MIN_VALUE));
		jp.setOpaque(false);
		
		ImageIcon img2 = new ImageIcon("image/title.png");
		JLabel ti = new JLabel(img2);
		ti.setBounds(0, 0,img2.getIconWidth(), img2.getIconHeight());
		
		JButton ViewButton,CollectionButton,RecycleButton,TestButton,ReturnButton;

		//�����ť
		ImageIcon img_v = new ImageIcon("image/view_icon.png");
		ViewButton = new JButton(img_v);
		ViewButton.setBounds(width/7*2-buttonWidth/2,height/3-buttonHeight/2-9*delta,buttonWidth,buttonHeight);
		ViewButton.setContentAreaFilled(false); 
		ViewButton.setBorder(emptyBorder);
		ViewButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				ViewPage VP = new ViewPage(jf);
				jf.remove(jp);
				jp = VP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});
		JLabel jl_v = new JLabel("<html><body><div style='color:#36648B;font-size:22px;font-family:����;'>���</div></body></html>");
		jl_v.setBounds(width/7*2-lableWidth/2,height/25*12-lableHeight/2-9*delta,lableWidth,lableHeight);

		//�ղذ�ť
		ImageIcon img_c = new ImageIcon("image/collection_icon.png");
		CollectionButton = new JButton(img_c);
		CollectionButton.setBounds(width/7*5-buttonWidth/2,height/3-buttonHeight/2-9*delta,buttonWidth,buttonHeight);
		CollectionButton.setContentAreaFilled(false); 
		CollectionButton.setBorder(emptyBorder);
		CollectionButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				CollectionPage CP = new CollectionPage(jf);
				jf.remove(jp);
				jp = CP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});
		JLabel jl_c = new JLabel("<html><body><div style='color:#36648B;font-size:22px;font-family:����;'>�ղ�</div></body></html>");
		jl_c.setBounds(width/7*5-lableWidth/2,height/25*12-lableHeight/2-9*delta,lableWidth,lableHeight);

		//���հ�ť
		ImageIcon img_r = new ImageIcon("image/recycle_icon.png");
		RecycleButton = new JButton(img_r);
		RecycleButton.setBounds(width/7*2-buttonWidth/2,height/3*2-10*delta-buttonHeight/2,buttonWidth,buttonHeight);
		RecycleButton.setContentAreaFilled(false); 
		RecycleButton.setBorder(emptyBorder);
		JLabel jl_r = new JLabel("<html><body><div style='color:#36648B;font-size:22px;font-family:����;'>����</div></body></html>");
		jl_r.setBounds(width/7*2-lableWidth/2,height/5*4-lableHeight/2-9*delta,lableWidth,lableHeight);
		RecycleButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				RecyclePage RP = new RecyclePage(jf);
				jf.remove(jp);
				jp = RP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});

		//���԰�ť
		ImageIcon img_t = new ImageIcon("image/test_icon.png");
		TestButton = new JButton(img_t);
		TestButton.setBounds(width/7*5-buttonWidth/2,height/3*2-10*delta-buttonHeight/2,buttonWidth,buttonHeight);
		TestButton.setContentAreaFilled(false); 
		TestButton.setBorder(emptyBorder);
		JLabel jl_t = new JLabel("<html><body><div style='color:#36648B;font-size:22px;font-family:����;'>����</div></body></html>");
		jl_t.setBounds(width/7*5-lableWidth/2,height/5*4-lableHeight/2-9*delta,lableWidth,lableHeight);
		TestButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				RecitePage RP = new RecitePage(jf);
				jf.remove(jp);
				jp = RP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});

		//���ذ�ť
		ImageIcon img_rt = new ImageIcon("image/return_icon.png");
		ReturnButton = new JButton(img_rt);
		ReturnButton.setBounds(width/9*8-returnWidth/2,height/7*6-returnHeight/2,returnWidth,returnHeight);
		ReturnButton.setContentAreaFilled(false); 
		ReturnButton.setBorder(emptyBorder);
		ReturnButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				VocabularyFrontpage FP = new VocabularyFrontpage(jf);
				jf.remove(jp);
				jp = FP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});

		jp.add(ViewButton);
		jp.add(CollectionButton);
		jp.add(RecycleButton);
		jp.add(TestButton);
		jp.add(ReturnButton);
		jp.add(jl_v);
		jp.add(jl_c);
		jp.add(jl_r);
		jp.add(jl_t);
		jp.add(ti);
		jp.add(bg);
		
		jp.setBounds(0, 0, width, height);
	}
}
