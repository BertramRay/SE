/*
 * ��дJbutton�࣬ʵ��Button���Ϸ�icon�·�����
 */

package gre3000;

import java.awt.*;
import javax.swing.*;

public class ButtonIconText extends JButton {
	private ImageIcon icon;
	private String text;
	private int FONT_SIZE = 14;
	private final Font font = new Font("Arial",Font.BOLD,FONT_SIZE);//���ֵ�����
	private final int BTN_WIDTH = 40;
	private final int BTN_HEIGHT = 70;
	private final int ICON_WIDTH = 40;
	private final int ICON_HEIGHT = 40;
	private int margin = 2;	//��
	
	public ButtonIconText(String iconAddress,String text0) {
		icon = new ImageIcon(iconAddress);
		text = text0;
		setBackground(Color.BLACK);
		setPreferredSize(new Dimension(BTN_WIDTH,BTN_HEIGHT));
	}
	
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		//����Icon��С
		Image img = icon.getImage();  
		Image newimg = img.getScaledInstance(ICON_WIDTH,ICON_HEIGHT,java.awt.Image.SCALE_SMOOTH) ;  
		icon = new ImageIcon(newimg);
		
		img = icon.getImage();
		g.drawImage(img,0,0,null);
		
		g.setColor(Color.WHITE);
		g.setFont(font);
		g.drawString(text, margin, (BTN_HEIGHT + ICON_HEIGHT)/2);
		
	}
}
