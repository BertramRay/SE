package gre3000;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;

public class RecitePage extends Page
{
	ArrayList<String> list = new ArrayList<String>();
	private int size = 3000;
	String a[] = new String[size];
	String b[] = new String[size];
	String word = new String();
	String paraphrase = new String();
	int wordGot = 0;
	int showAns = 0;
	int page = 1;
	int pageMax = 1008611;
	public RecitePage(JFrame jf) {
		super(jf);
		// TODO Auto-generated constructor stub
	}

	public void setPageNum(int n)
	{
		page = n;
	}
	
	public String getK(String name)
	{
		String cmd = "remember";
		String command[] = {exe2,cmd,name};
		String buffer = new String();
		try {
			Process process = Runtime.getRuntime().exec(command);
			java.io.InputStream is = process.getInputStream();
			DataInputStream  dis = new DataInputStream(is);
			InputStreamReader isr = new InputStreamReader (dis);
			BufferedReader br = new BufferedReader(isr);
			buffer = br.readLine();
			
			try {
				process.waitFor();
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return buffer;
	}
	
	
	public ArrayList<String> readFromTextFile(String pathname) throws IOException
	{
	    ArrayList<String> strArray = new ArrayList<String>();
	    File filename = new File(pathname);
	    InputStreamReader reader = new InputStreamReader(new FileInputStream(filename));
	    BufferedReader br = new BufferedReader(reader);
	    String line = "";
	    line = br.readLine();
	    while(line != null) 
	    {
	        strArray.add(line);
	        line = br.readLine();
	    }
	    return strArray;
	}
	
	public void input() throws IOException
	{
		DefaultListModel<String> model_a = new DefaultListModel<>();
		DefaultListModel<String> model_b = new DefaultListModel<>();
    	String init[] = {"cmd","/k","main.exe"};
    	String cmd[] = {"recite collection",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter",
    			"latter","latter","latter","latter","latter","latter"
    	};
    	
		try
    	{
			Process process1 = Runtime.getRuntime().exec(init);
			PrintWriter out = new PrintWriter(process1.getOutputStream());
			java.io.InputStream is = process1.getInputStream();
			DataInputStream  dis = new DataInputStream(is);
			InputStreamReader isr = new InputStreamReader (dis);
			BufferedReader br = new BufferedReader(isr);
			for(int i=0;i<page;i++)
			{
				out.println(cmd[i]);
				out.flush(); 
				//System.out.println(cmd[i]);
				String s = br.readLine();
				//System.out.println(s);
				if(s.length()==0)
					break;
				if(s.charAt(0)=='$')
				{
					pageMax = page;
					word = br.readLine();
				}
				else
					word = s;
			}
			out.println("quit");
			out.flush(); //д������̨ 
    	}
		catch (IOException e1) 
		{
		// TODO Auto-generated catch block
		e1.printStackTrace();
		}
		
		
	}
	
	public void setPage()
	{
		jp.setLayout(null);
		
		buttonWidth = 100;
		buttonHeight = 40;

		width = jf.getWidth();
		height = jf.getHeight();
		
		int delta = width/100;
		
		//����������
		ImageIcon img1 = new ImageIcon("image/background.jpg");
		JLabel bg=new JLabel(img1);
		bg.setBounds(0, 0,img1.getIconWidth(), img1.getIconHeight());
		jf.getLayeredPane().add(bg, new Integer(Integer.MIN_VALUE));
		jp.setOpaque(false);
		
		ImageIcon img2 = new ImageIcon("image/title.png");
		JLabel ti = new JLabel(img2);
		ti.setBounds(0, 0,img2.getIconWidth(), img2.getIconHeight());
		
		if(wordGot == 0)
		{
			try {
				input();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			String cmd2 = "search";
			String argv1 = word;
			String command[] = {exe2,cmd2,argv1};
			
			try {
				Process process = Runtime.getRuntime().exec(command);
				java.io.InputStream is = process.getInputStream();
				DataInputStream  dis = new DataInputStream(is);
				InputStreamReader isr = new InputStreamReader (dis);
				BufferedReader br = new BufferedReader(isr);
				paraphrase = br.readLine();
				
				try {
					process.waitFor();
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
		}
		JButton SearchButton;
		ImageIcon img_s = new ImageIcon("image/search.png");
		SearchButton = new JButton(img_s);
		SearchButton.setContentAreaFilled(false); 
		SearchButton.setBorder(emptyBorder);
		SearchButton.setBounds(width/2+29*delta,height/2-20*delta-2*delta,90,90);
		SearchButton.addMouseListener(new MouseAdapter() 
		{
			public void mousePressed(MouseEvent e) 
			{
				RecitePage RP = new RecitePage(jf);
				jf.remove(jp);
				RP.wordGot = 1;
				RP.word = word;
				RP.paraphrase = paraphrase;
				RP.page = page;
				RP.showAns = showAns^1;
				jp = RP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});
		
		
		JLabel wordLabel = new JLabel();
		wordLabel = new JLabel("<html><body><div style='color:#36648B;font-size:22px;font-family:����;'>"+word+"</div></body></html>");
		wordLabel.setBounds(width/2-25*delta,height/2-15*delta,20*delta,10*delta);
		
		wordLabel.addMouseListener(new MouseAdapter() 
		{
			public void mousePressed(MouseEvent e) 
			{
				;
				WordPage WP = new WordPage(jf);
				WP.setName(word);
				WP.setparaphrase(paraphrase);

				WP.setK(getK(word));
				WP.setCategory(VIEW);
				jf.remove(jp);
				jp = WP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});
		
		JLabel paraphraseLabel = new JLabel();
		paraphraseLabel = new JLabel("<html><body><div style='color:#36648B;font-size:22px;font-family:����;'>"+paraphrase+"</div></body></html>");
		paraphraseLabel.setBounds(width/2-25*delta,height/2-5*delta,30*delta,10*delta);
		paraphraseLabel.addMouseListener(new MouseAdapter() 
		{
			public void mousePressed(MouseEvent e) 
			{
				WordPage WP = new WordPage(jf);
				WP.setName(word);
				WP.setparaphrase(paraphrase);
				WP.setK(getK(word));
				WP.setCategory(VIEW);
				jf.remove(jp);
				jp = WP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});
		
		
		JButton ReturnButton;
		ImageIcon img_rt = new ImageIcon("image/return_icon.png");
		ReturnButton = new JButton(img_rt);
		ReturnButton.setBounds(width/9*8-returnWidth/2,height/7*6-returnHeight/2,returnWidth,returnHeight);
		ReturnButton.setContentAreaFilled(false); 
		ReturnButton.setBorder(emptyBorder);
		ReturnButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				VocabularyPage FP = new VocabularyPage(jf);
				jf.remove(jp);
				jp = FP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});

		ImageIcon img_last = new ImageIcon("image/last.png");
		JButton LastButton =  new JButton(img_last);
		LastButton.setBounds(width/2-40*delta,height/2-5*delta,80,80);
		LastButton.setContentAreaFilled(false); 
		LastButton.setBorder(emptyBorder);
		LastButton.addMouseListener(new MouseAdapter() 
		{
			public void mousePressed(MouseEvent e) 
			{
				RecitePage CP = new RecitePage(jf);
				jf.remove(jp);
				if(page>1)
					page--;
				CP.setPageNum(page);
				jp = CP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});

		ImageIcon img_next = new ImageIcon("image/next.png");
		JButton NextButton =  new JButton(img_next);
		NextButton.setBounds(width/2+30*delta,height/2-5*delta,80,80);
		NextButton.setContentAreaFilled(false); 
		NextButton.setBorder(emptyBorder);
		
		NextButton.addMouseListener(new MouseAdapter() 
		{
			public void mousePressed(MouseEvent e) 
			{
				RecitePage CP = new RecitePage(jf);
				jf.remove(jp);
				if(page<pageMax)
					page++;
				CP.setPageNum(page);
				jp = CP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});

		jp.add(ReturnButton);
		jp.add(LastButton);
		jp.add(SearchButton);
		jp.add(NextButton);
		jp.add(wordLabel);
		if(showAns==1)
			jp.add(paraphraseLabel);
		jp.add(ti);
		jp.add(bg);
		
		jp.setBounds(0, 0, width, height);
	}
}
