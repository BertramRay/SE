package gre3000;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import java.io.IOException;
//��Ϊ���ʣ����⣬����������ť

public class Mainpage extends JFrame implements ActionListener{
	FilletButton wordButton,exerciseButton,returnButton;
	public static void main(String[] args){
		Mainpage app=new Mainpage();
		app.go();

	}
	public void go() {//go�������ڴ���������
		setTitle("GRE3000");
		setSize(1000,700);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);//�̶������С
		ImageIcon bg=new ImageIcon("img/bg.jpg");
		JLabel label=new JLabel(bg);
		label.setBounds(0,0,bg.getIconWidth(),bg.getIconHeight());//�����ͼƬ�ȴ�
		getLayeredPane().add(label,new Integer(-30001));//������Щ����֮�£�С��-30000����
		JPanel contentPane=(JPanel)getContentPane();
		contentPane.setOpaque(false);//���ñ���Ϊ͸������Ȼ��ѱ���ͼƬ��ס
		contentPane.setLayout(new BorderLayout());
		JPanel ButtonPanel=getButtonPanel();
		ButtonPanel.setOpaque(false);
		contentPane.add(ButtonPanel,"Center");
		contentPane.add(new JLabel(" "),"North");//������׿հ�
		contentPane.add(new JLabel(" "),"South");//�ײ����հ�
		/*JFrame.setDefaultLookAndFeelDecorated(true);
		JDialog.setDefaultLookAndFeelDecorated(true);
		try {
			UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (Exception evt) {}*/
		setVisible(true);
	}
	private JPanel getButtonPanel() {
		JPanel buttonpanel=new JPanel();
		buttonpanel.setLayout(null);
		Font font = new Font("����",Font.BOLD,40);
		wordButton=new FilletButton("��   ��");
		wordButton.setBounds(300,150,400,100);
		wordButton.setFont(font);
		wordButton.setFocusPainted(false);
		wordButton.setBorderPainted(false);
		//wordButton.setOpaque(false);
		buttonpanel.add(wordButton);
		wordButton.setBorder(BorderFactory.createLineBorder(Color.black));
		wordButton.addActionListener(this);
		exerciseButton=new FilletButton("ˢ   ��");
		exerciseButton.setBounds(300,350,400,100);
		exerciseButton.setFont(font);
		exerciseButton.setBorder(BorderFactory.createLineBorder(Color.black));
		exerciseButton.setFocusPainted(false);
		exerciseButton.setBorderPainted(false);
		//exerciseButton.setOpaque(false);
		buttonpanel.add(exerciseButton);
		exerciseButton.addActionListener(this);
		return(buttonpanel);

	}
	public void actionPerformed(ActionEvent e) {//��������
		if(e.getSource()==wordButton)  {
			this.dispose();
			Mainpage wordpage=new Mainpage();
			wordpage.goword();
		}
		if(e.getSource()==exerciseButton) {
			this.dispose();
			Mainpage exercisepage = new Mainpage();
			javax.swing.SwingUtilities.invokeLater(new Runnable(){//ˢ�����
				public void run() {
					Questioning q = new Questioning();
					q.readSetting();			//��ȡ������Ϣ
					q.getCollection();			//��ȡ���ղص����
					q.getQuestionNo();			//�������û�ȡ��Ӧ�����
					if(0 < q.qNum) {			//����Ŀʱ
						q.readQuestion(q.qNo[--q.qNum]);	//��ȡ�����С����Ŀ��������Ϣ
					}
					q.questioningPage();		//��ʾҳ��
				}
			});
		}
		if(e.getSource()==returnButton) {
			this.dispose();
			Mainpage mainpage=new Mainpage();
			mainpage.go();
		}

	}
	public void goword() {
		JFrame frame = new JFrame();
		JPanel panel = new JPanel();
		VocabularyFrontpage Fp = new VocabularyFrontpage(frame);
		try {
		FrameInit.frameInit(frame);
		}catch(IOException e) {
			System.out.println("IOException");
		}catch(InterruptedException e) {
			System.out.println("InterruptedException");
		}
		//System.out.println("miao");
		frame.setResizable(false); 
		panel = Fp.createPage(frame);
		frame.add(panel);
		//frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.setVisible(true);
	}
}


