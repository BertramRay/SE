package gre3000;

import java.io.IOException;

import javax.swing.JFrame;

public class FrameInit 
{
	JFrame jf;
	static String exe = "search.exe";
	public static void frameInit(JFrame jf) throws IOException, InterruptedException
	{
		Process process = Runtime.getRuntime().exec(exe+" new dictlist");
		process.waitFor();
		jf.setLayout(null);
		jf.setBounds(0, 0, 1000, 750);
	}
}
