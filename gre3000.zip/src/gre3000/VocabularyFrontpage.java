package gre3000;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VocabularyFrontpage extends Page
{
	
	public VocabularyFrontpage(JFrame jf) 
	{
		super(jf);
		// TODO Auto-generated constructor stub
	}

	public void setPage()
	{
		jp.setLayout(null);
		
		buttonWidth = 200;
		buttonHeight = 200;
		lableWidth = 65;
		lableHeight = 40;

		width = jf.getWidth();
		height = jf.getHeight();
		
		//String curDir = System.getProperty("user.dir");
		
		//����������
		ImageIcon img1 = new ImageIcon("image/background.jpg");
		JLabel bg=new JLabel(img1);
		bg.setBounds(0, 0,img1.getIconWidth(), img1.getIconHeight());
		jf.getLayeredPane().add(bg, new Integer(Integer.MIN_VALUE));
		jp.setOpaque(false);
		
		ImageIcon img2 = new ImageIcon("image/title.png");
		JLabel ti = new JLabel(img2);
		ti.setBounds(0, 0,img2.getIconWidth(), img2.getIconHeight());
		
		//System.out.printf("%d %d",width,height);
		JButton VocabularyButton,LearnButton;
		
		//�ʻ㰴ť
		ImageIcon img_v = new ImageIcon("image/vocabulary_icon.png");
		VocabularyButton = new JButton(img_v);
		VocabularyButton.setBounds(width/7*2-buttonWidth/2, height/9*4-buttonHeight/2, buttonWidth, buttonHeight);
		VocabularyButton.setContentAreaFilled(false); 
		VocabularyButton.setBorder(emptyBorder);
		VocabularyButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				//System.out.println("vocabulary is clicked");
				
				VocabularyPage VP = new VocabularyPage(jf);
				jf.remove(jp);
				jp = VP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
				
			}
		});
		JLabel jl_v = new JLabel("<html><body><div style='color:#36648B;font-size:22px;font-family:����;'>�ʻ�</div></body></html>");
		jl_v.setBounds(width/7*2-lableWidth/2,height/11*7-lableHeight/2,lableWidth,lableHeight);
		
		//ѧϰ��ť
		ImageIcon img_l = new ImageIcon("image/learn_icon.png");
		LearnButton = new JButton(img_l);
		LearnButton.setBounds(width/7*5-buttonWidth/2, height/9*4-buttonHeight/2, buttonWidth, buttonHeight);
		LearnButton.setContentAreaFilled(false); 
		LearnButton.setBorder(emptyBorder);
		LearnButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				LearnPage LP = new LearnPage(jf);
				jf.remove(jp);
				jp = LP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}   
		});
		JLabel jl_l = new JLabel("<html><body><div style='color:#36648B;font-size:22px;font-family:����;'>ѧϰ</div></body></html>");
		jl_l.setBounds(width/7*5-lableWidth/2,height/11*7-lableHeight/2,lableWidth,lableHeight);
	
		jp.add(VocabularyButton);
		jp.add(LearnButton);
		jp.add(jl_v);
		jp.add(jl_l);
		jp.add(ti);
		jp.add(bg);
		
		jp.setBounds(0, 0, width, height);
	}
}
