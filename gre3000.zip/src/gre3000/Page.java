package gre3000;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;

public class Page
{
	public Border emptyBorder = BorderFactory.createEmptyBorder(0,0, 0, 0);
	public int width,height;
	public int buttonWidth,buttonHeight;
	public int lableWidth,lableHeight;
	public int returnWidth = 80,returnHeight = 80;

	public static String exe1 = "./main.exe";
	public static String exe2 = "./search.exe";
	static final int VIEW = 1;
	static final int COLLECTION = 2;
	static final int RECYCLE = 3;
	
	static final String K = "k";
	static final String UNK = "unk";
	
	
	JPanel jp = new JPanel();
	JFrame jf;
	public Page(JFrame jf)
	{
		this.jf = jf;
	}
	public JPanel createPage(JFrame jf)
	{
		this.jf = jf;
		setPage();
		return jp;
	}
	public JPanel createPage()
	{
		setPage();
		return jp;
	}
	public void setPage()
	{
		/*
		 * Add JPanel Settings Here
		 */
	}
}
