package gre3000;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LearnPage extends Page
{
	public LearnPage(JFrame jf) {
		super(jf);
		// TODO Auto-generated constructor stub
	}

	public void setPage()
	{
		jp.setLayout(null);
	
		buttonWidth = 180;
		buttonHeight = 180;
		lableWidth = 65;
		lableHeight = 40;
		
		width = jf.getWidth();
		height = jf.getHeight();
		
		int delta = width/200;
		
		//����������
		ImageIcon img1 = new ImageIcon("image/background.jpg");
		JLabel bg=new JLabel(img1);
		bg.setBounds(0, 0,img1.getIconWidth(), img1.getIconHeight());
		jf.getLayeredPane().add(bg, new Integer(Integer.MIN_VALUE));
		jp.setOpaque(false);
						
		ImageIcon img2 = new ImageIcon("image/title.png");
		JLabel ti = new JLabel(img2);
		ti.setBounds(0, 0,img2.getIconWidth(), img2.getIconHeight());
		
		JButton DailyButton,SectionButton,ScheduleButton,ReturnButton;
		ImageIcon img_d = new ImageIcon("image/daily_icon.png");
		DailyButton = new JButton(img_d);
		DailyButton.setBounds(width/4-buttonWidth/2-5*delta,height/5*2-buttonHeight/2,buttonWidth,buttonHeight);
		DailyButton.setContentAreaFilled(false); 
		DailyButton.setBorder(emptyBorder);
		JLabel jl_d = new JLabel("<html><body><div style='color:#36648B;font-size:22px;font-family:����;'>ÿ��</div></body></html>");
		jl_d.setBounds(width/4-5*delta-lableWidth/2,height/5*2-lableHeight/2+22*delta,lableWidth,lableHeight);


		ImageIcon img_s = new ImageIcon("image/section_icon.png");
		SectionButton = new JButton(img_s);
		SectionButton.setBounds(width/2-buttonWidth/2,height/5*2-buttonHeight/2,buttonWidth,buttonHeight);
		SectionButton.setContentAreaFilled(false); 
		SectionButton.setBorder(emptyBorder);
		JLabel jl_s = new JLabel("<html><body><div style='color:#36648B;font-size:22px;font-family:����;'>��Ԫ</div></body></html>");
		jl_s.setBounds(width/2-lableWidth/2,height/5*2-lableHeight/2+22*delta,lableWidth,lableHeight);

		ImageIcon img_sch = new ImageIcon("image/schedule_icon.png");
		ScheduleButton = new JButton(img_sch);
		ScheduleButton.setBounds(width/4*3-buttonWidth/2+5*delta,height/5*2-buttonHeight/2,buttonWidth,buttonHeight);
		ScheduleButton.setContentAreaFilled(false); 
		ScheduleButton.setBorder(emptyBorder);
		JLabel jl_sch = new JLabel("<html><body><div style='color:#36648B;font-size:22px;font-family:����;'>�ƻ�</div></body></html>");
		jl_sch.setBounds(width/4*3+5*delta-lableWidth/2,height/5*2-lableHeight/2+22*delta,lableWidth,lableHeight);
		
		ImageIcon img_rt = new ImageIcon("image/return_icon.png");
		ReturnButton = new JButton(img_rt);
		ReturnButton.setBounds(width/9*8-returnWidth/2,height/7*6-returnHeight/2,returnWidth,returnHeight);
		ReturnButton.setContentAreaFilled(false); 
		ReturnButton.setBorder(emptyBorder);
		ReturnButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				VocabularyFrontpage FP = new VocabularyFrontpage(jf);
				jf.remove(jp);
				jp = FP.createPage();
				jf.add(jp);
				jp.revalidate();
				jp.repaint();
			}
		});
		jp.add(DailyButton);
		jp.add(SectionButton);
		jp.add(ScheduleButton);
		jp.add(ReturnButton);
		jp.add(jl_d);
		jp.add(jl_s);
		jp.add(jl_sch);
		jp.add(ti);
		jp.add(bg);
		
		jp.setBounds(0,0,width,height);
	}
	
}
