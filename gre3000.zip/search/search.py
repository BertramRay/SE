import json
import os
import show
import recite
import sys

# Get user ID
ID = '000000'

# Get dictionary and list settings
if os.path.exists(ID):
	with open(ID + '\\attrib.txt') as file:
		attrib = json.loads(file.read())
	dict_file = attrib[ID+'dict_file']
	list_file = attrib[ID+'list_file']
else:
	os.mkdir(ID + '\\')
	attrib = {}
	attrib[ID+'dict_file'] = ['dict']
	attrib[ID+'list_file'] = []
	dict_file = ['dict']
	list_file = []

# Load dictionary
dictionarys = {}
word_lists = {}
for dictionary in dict_file:
	with open(dictionary + '.txt') as file:
		dictionarys[dictionary] = json.loads(file.read())
for word_list in list_file:
	with open(ID + '\\' + word_list + '.txt') as file:
		word_lists[word_list] = json.loads(file.read())

# core
dict_set = 'dict'
now_list = 'collection'
cmd = ''
#while True:
#cmd = input().split()

# Words

if sys.argv[1] == 'search':
	if sys.argv[2] in dictionarys[dict_set]:
		print(dictionarys[dict_set][sys.argv[2]]['CN'])
	else:
		print('404')
elif sys.argv[1] == 'remember':
	try:
		print(attrib[sys.argv[2]])
	except:
		print('unk')
	
elif sys.argv[1] == 'k':	
	attrib[sys.argv[2]] = 'k'

elif sys.argv[1] == '?':
	attrib[sys.argv[2]] = '?'

elif sys.argv[1] == 'unk':
	attrib[sys.argv[2]] = 'unk'

	# Word Lists

elif sys.argv[1] == 'lists':
	for item in word_lists.keys():
		print(item)

elif sys.argv[1] == 'new':
	if not sys.argv[2] in word_lists:
		word_lists[sys.argv[2]] = []
		attrib[ID+'list_file'].append(sys.argv[2])
		print('Done')
	else:
		print('Exist')

elif sys.argv[1] == 'remove':
	if sys.argv[2] in word_lists:
		del word_lists[sys.argv[2]]
		attrib[ID+'list_file'].remove(sys.argv[2])
		print('Done')
	else:
		print('404')

elif sys.argv[1] == 'add':
	if word_lists[sys.argv[3]].count(sys.argv[2]) == 0:
		word_lists[sys.argv[3]].append(sys.argv[2])

elif sys.argv[1] == 'del':
	if word_lists[sys.argv[3]].count(sys.argv[2]) == 1:
		word_lists[sys.argv[3]].remove(sys.argv[2])

	# Operation

elif sys.argv[1] == 'show':
	now_list = show.Show(word_lists[sys.argv[2]], dictionarys[dict_set])

elif sys.argv[1] == 'recite':
	now_list = recite.Recite(word_lists[sys.argv[2]], dictionarys[dict_set])

elif sys.argv[1] == 'former':
	now_list.former()

elif sys.argv[1] == 'latter':
	now_list.latter()

elif sys.argv[1] == 'leave':
	del now_list		

# Save data
with open(ID + '\\attrib.txt', 'w') as file:
	file.write(json.dumps(attrib))
for word_list in word_lists.keys():
	with open(ID + '\\' + word_list + '.txt', 'w') as file:
		file.write(json.dumps(word_lists[word_list]))
