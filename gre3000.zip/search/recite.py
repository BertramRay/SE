class Recite:

	def __init__(self, word_list, dictionary):
		self.word_list = word_list
		self.len = word_list.__len__()
		self.dictionary = dictionary
		self.i = 0
		print(self.word_list[self.i])

	def former(self):
		if self.i > 0:
			self.i -= 1
			print(self.word_list[self.i])

	def latter(self):
		if self.i < self.len - 1:
			self.i += 1
			print(self.word_list[self.i])