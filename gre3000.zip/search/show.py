class Show:

	num_of_page = 8

	def __init__(self, word_list, dictionary):
		self.word_list = word_list
		self.len = word_list.__len__()
		self.dictionary = dictionary
		self.i = 0
		for word in word_list[0: min(Show.num_of_page, self.len)]:
			print(word, dictionary[word]['CN'])

	def former(self):
		if self.i >= Show.num_of_page:
			self.i -= Show.num_of_page
		for word in self.word_list[self.i: min(self.len, self.i + Show.num_of_page)]:
			print(word, self.dictionary[word]['CN'])

	def latter(self):
		if self.i + Show.num_of_page < self.len:
			self.i += Show.num_of_page
		for word in self.word_list[self.i: min(self.len, self.i + Show.num_of_page)]:
			print(word, self.dictionary[word]['CN'])